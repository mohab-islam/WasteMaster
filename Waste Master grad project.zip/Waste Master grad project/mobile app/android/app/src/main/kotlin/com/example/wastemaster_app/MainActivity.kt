package com.example.wastemaster_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
